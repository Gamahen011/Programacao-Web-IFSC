<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


for ($i = 1; $i <= 10; $i++) {
    echo "<p>$i</p <br>";
};

?>